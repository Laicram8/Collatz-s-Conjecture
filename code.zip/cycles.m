clc
N=10^4;
J=10^7;
l=2.26079*10^25;
count=0;
count1=0;
top1=zeros(1,J);
j=zeros(1,J);
for x1=1:J;
    x(1)=x1;
    for i=1:N;
    n(i)=fix((x(i) + 1)/3); 
    d(i)=2+(3-mod(x(i),3))*mod(x(i),3);
    r(i)=(-1/2-3/2*(-2+mod(x(i),3)))*mod(x(i),3);
    x(i+1)=d(i)*n(i)+r(i);
    if x(i)>l
       top=[x1,i];
       top1(x1)=i;
       count=count+1;
       break
    else
         if any(x(1:i-1) == x(i))
             cycle1 =[i,x1]
             count1=count1+1;
             cycles2(count1)=x1;
             length(count1)=i;
             break
        else
            continue
        end
    end
    end  
    if x(i)>l
      j(x1)=0;
    else
        j(x1)=x1;
    end
    
end
k=J-count;

figure(1);
scatter(1:J,top1)

figure(2);
scatter(1:111,j(1:111))